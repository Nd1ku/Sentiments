
const express = require('express');
const Sentiment = require('sentiment');
const cors = require('cors');
const path = require('path');  // Add this line to use the path module

const app = express();
const sentiment = new Sentiment();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Serve your index.html file when the root route is accessed
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.post('/analyze', (req, res) => {
    const { text } = req.body;
    const result = sentiment.analyze(text);
    res.json({ sentiment: result });
});


app.post('/analyze', (req, res) => {
    const { text } = req.body;
    const analysisResult = sentiment.analyze(text);
    const sentimentType = analysisResult.score > 0 ? 'Positive' : analysisResult.score < 0 ? 'Negative' : 'Neutral';

    // Send the response with the score and type at the top level of the object
    res.json({ score: analysisResult.score, type: sentimentType });
});


const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
