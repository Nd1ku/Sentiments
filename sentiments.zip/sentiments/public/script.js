
function analyzeSentiment() {
    const text = document.getElementById('text-to-analyze').value;
    fetch('/analyze', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ text: text })
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('result').innerText = 'Sentiment Score: ' + data.sentiment.score;
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('result').innerText = 'Error analyzing sentiment.';
    });
}
function analyzeSentiment() {
    const textArea = document.getElementById('text-to-analyze');
    const resultDiv = document.getElementById('result');

    // Check if the elements are correctly selected
    console.log('Text area:', textArea);
    console.log('Result div:', resultDiv);

    fetch('/analyze', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ text: textArea.value })
    })
    .then(response => {
        // Check the raw response
        console.log('Raw response:', response);
        return response.json();
    })
    .then(data => {
        // Log the data to see what's received from the server
        console.log('Received data:', data);

        // Extract the sentiment score from the nested object
        const sentimentScore = data.sentiment?.score;
        // Log the extracted score
        console.log('Sentiment scores:', sentimentScore);

        // Determine the sentiment type based on the score
        let sentimentType;
        if (sentimentScore > 0) {
            sentimentType = 'Positive';
        } else if (sentimentScore < 0) {
            sentimentType = 'Negative';
        } else {
            sentimentType = 'Neutral';
        }


resultDiv.innerText = `Sentiment Score: ${sentimentScore}\nSentiment Type: ${sentimentType}`;

    })
    .catch(error => {
        // Log any errors that occur during the fetch operation
        console.error('Error fetching and parsing data:', error);
        resultDiv.innerText = 'Error analyzing sentiment.';
    });
}

// Make sure this function is accessible globally if it's called from inline HTML event attributes
window.analyzeSentiment = analyzeSentiment;
